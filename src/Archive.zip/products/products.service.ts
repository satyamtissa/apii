import { Inject, Injectable } from '@nestjs/common';
import { plainToClass } from 'class-transformer';
import { CreateProductsDto } from './dto/create-products.dto';
import { GetProductsDto } from './dto/get-products.dto';
import { UpdateProductsDto } from './dto/update-products.dto';
import { Products } from './entities/products.entity';
import Fuse from 'fuse.js';
import { paginate } from '../common/pagination/paginate';
import { Db, ObjectID } from 'mongodb';

const options = {
  keys: ['name', 'slug'],
  threshold: 0.3,
  
};

@Injectable()
export class ProductsService {
  private products: any ;
  private fuse: any;
  constructor(
    @Inject('DATABASE_CONNECTION')
    private db: Db,
  ) {
    this.init();
    

  }

  async init() {
  
    this.products = await this.db.collection('products').find().toArray();
    console.log("In service DDBB products=====")
    this.fuse=new Fuse(this.products, options);
    
}
  create(createproductDto: CreateProductsDto) {
    return this.products[0];
  }

  getProducts({ limit, page, search, parent, q}: GetProductsDto) {
    console.log("In service get products====="+ JSON.stringify({ limit, page, search, parent, q }))
    
    if (!page) page = 1;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    let data: Products[] = this.products;
  
    if (search) {
      const searchParams = search.split(';');
      const queryParams = searchParams.map(param => {
        const [key, value] = param.split(':');
        return { key, value };
        console.log("inside search")
      });
    
      const qParam = queryParams.find(param => param.key === 'q');
      if (qParam) {
        const q = qParam.value.toLowerCase();
        data = this.products.find(product => product.slug.toLowerCase() === q);
        console.log("inside qParam")
      }
    } else if (q) {
      const searchStr = q.toLowerCase();
      data = this.products.find(product => product.slug.toLowerCase() === searchStr);
      console.log('searchstr',searchStr)
      console.log("inside q")
    }
    const results = data
    
    //const url = `/search?search=${search || 'q:' + q}&limit=${limit}`;
   // const url = `/search?q=Stunning Butterfly Pearl Necklace&limit=${limit}`;
    const url = `/search?q=${q}&limit=${limit}`;
    console.log("result",results)
    return {
      data: results,
      
      ...paginate(data.length, page, limit, results.length, url),
    };
  }
  
  
  
  
  

  getProduct(param: string, language: string): Products {
    return this.products.find( 
      (p) => p.id === Number(param) || p.slug === param,
    );
  }

  update(id: number, updateProductDto: UpdateProductsDto) {
    return this.products[0];
  }

  remove(id: number) {
    return `This action removes a #${id} product`;
  }


  /*getProductBySlug(slug: string) {
    console.log("testing the data")
    return this.db.collection('products').findOne({ slug });

  }*/


}
