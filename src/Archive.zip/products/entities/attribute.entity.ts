import { CoreEntity } from "../../common/entities/core.entity";

export class Attribute extends CoreEntity  
{ 
    name : string;
    slug : string;
    

    
}
